# aspnet-core-registration-login-api

ASP.NET Core 2.2 - API for User Management, Authentication and Registration

For documentation and instructions check out http://jasonwatmore.com/post/2018/06/26/aspnet-core-21-simple-api-for-authentication-registration-and-user-management
